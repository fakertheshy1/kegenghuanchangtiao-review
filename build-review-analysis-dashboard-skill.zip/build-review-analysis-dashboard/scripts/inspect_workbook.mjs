import fs from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";

const runtimeModules = process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES;
if (!runtimeModules) throw new Error("CODEX_PRIMARY_RUNTIME_NODE_MODULES is not set");
const artifactToolUrl = pathToFileURL(path.join(runtimeModules, "@oai/artifact-tool/dist/artifact_tool.mjs")).href;
const { FileBlob, SpreadsheetFile } = await import(artifactToolUrl);

const [inputPath, outputPath] = process.argv.slice(2);
if (!inputPath || !outputPath) throw new Error("Usage: node inspect_workbook.mjs input.xlsx output.json");

const input = await FileBlob.load(inputPath);
const workbook = await SpreadsheetFile.importXlsx(input);
const sheetInfo = JSON.parse((await workbook.inspect({ kind: "sheet", include: "id,name", maxChars: 20000 })).json || "null");

function valueType(value, formula) {
  if (formula) return "formula";
  if (value === null || value === undefined || value === "") return "blank";
  if (value instanceof Date) return "date";
  if (["string", "number", "boolean"].includes(typeof value)) return typeof value;
  return "other";
}

const sheets = [];
for (let index = 0; index < workbook.worksheets.items.length; index++) {
  const sheet = workbook.worksheets.getItemAt(index);
  const used = sheet.getUsedRange(false);
  if (!used) {
    sheets.push({ index: index + 1, name: sheet.name, usedRange: null, rows: 0, columns: 0, values: [], formulas: [] });
    continue;
  }
  const values = used.values;
  const formulas = used.formulas;
  const rows = values.length;
  const columns = Math.max(0, ...values.map((row) => row.length));
  const typeCounts = { blank: 0, string: 0, number: 0, boolean: 0, date: 0, formula: 0, other: 0 };
  let nonBlank = 0;
  let formulaCount = 0;
  for (let row = 0; row < rows; row++) {
    for (let column = 0; column < columns; column++) {
      const value = values[row]?.[column] ?? null;
      const formula = formulas?.[row]?.[column] || null;
      const type = valueType(value, formula);
      typeCounts[type]++;
      if (type !== "blank") nonBlank++;
      if (formula) formulaCount++;
    }
  }
  sheets.push({ index: index + 1, name: sheet.name, usedRange: used.address, rows, columns, nonBlank, blankWithinUsedRange: rows * columns - nonBlank, formulaCount, typeCounts, values, formulas });
}

await fs.writeFile(outputPath, JSON.stringify({ inputPath, sheetInfo, sheetCount: sheets.length, sheets }, null, 2));
